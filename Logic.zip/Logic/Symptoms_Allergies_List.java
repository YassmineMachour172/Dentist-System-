package Logic;

public class Symptoms_Allergies_List {
	private String symptomNum;
	private String allergiesNum;
	private String ASList;

	
	public String getASList() {
		return ASList;
	}
	public void setASList(String aSList) {
		ASList = aSList;
	}
	public Symptoms_Allergies_List(String symptomNum, String allergiesNum, String aSList) {
		super();
		this.symptomNum = symptomNum;
		this.allergiesNum = allergiesNum;
		ASList = aSList;
	}
	public String getSymptomNum() {
		return symptomNum;
	}
	public void setSymptomNum(String symptomNum) {
		this.symptomNum = symptomNum;
	}
	public String getAllergiesNum() {
		return allergiesNum;
	}
	public void setAllergiesNum(String allergiesNum) {
		this.allergiesNum = allergiesNum;
	}
	@Override
	public String toString() {
		return "Symptoms_Allergies_List [symptomNum=" + symptomNum + ", allergiesNum=" + allergiesNum + ", ASList="
				+ ASList + "]";
	}

	
}
