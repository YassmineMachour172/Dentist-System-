package Logic;

import java.util.Date;

public class Manager extends Doctor {
	
	private int managerNum;
	private String ProgramPass;
	
	
	public Manager(String fName, String lName, String id, Date birthday, String phone, String country, String street,
			String buildingNum, String gender, String username, String password, boolean isConnected, String color,
			String job, int docNum, int managerNum, String programPass) {
		super(fName, lName, id, birthday, phone, country, street, buildingNum, gender, username, password, isConnected,
				color, job, docNum);
		this.managerNum = managerNum;
		ProgramPass = programPass;
	}
	
	public int getManagerNum() {
		return managerNum;
	}
	public String getProgramPass() {
		return ProgramPass;
	}
	public void setManagerNum(int managerNum) {
		this.managerNum = managerNum;
	}
	public void setProgramPass(String programPass) {
		ProgramPass = programPass;
	}
	@Override
	public String toString() {
		return super.toString() + "Manager [managerNum=" + managerNum + ", ProgramPass=" + ProgramPass + "]";
	}
	
	

}
