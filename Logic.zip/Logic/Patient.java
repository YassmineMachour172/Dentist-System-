package Logic;

import java.util.Date;

public abstract class Patient extends Person {
	
	private int patientNum;
	private int payments;
	private int weight;
	private int height;
	private XRAY[] pictures;
	
	
	
	public Patient(String fName, String lName, String id, Date birthday, String phone, String country, String street,
			String buildingNum, String gender, int patientNum, int payments, int weight, int height, XRAY[] pictures) {
		super(fName, lName, id, birthday, phone, country, street, buildingNum, gender);
		this.patientNum = patientNum;
		this.payments = payments;
		this.weight = weight;
		this.height = height;
		this.pictures = pictures;
	}
	
	public int getPatientNum() {
		return patientNum;
	}
	public int getPayments() {
		return payments;
	}
	public int getWeight() {
		return weight;
	}
	public int getHeight() {
		return height;
	}
	public XRAY[] getPictures() {
		return pictures;
	}
	public void setPatientNum(int patientNum) {
		this.patientNum = patientNum;
	}
	public void setPayments(int payments) {
		this.payments = payments;
	}
	public void setWeight(int weight) {
		this.weight = weight;
	}
	public void setHeight(int height) {
		this.height = height;
	}
	public void setPictures(XRAY[] pictures) {
		this.pictures = pictures;
	}
	@Override
	public String toString() {
		return super.toString() + "Patient [patientNum=" + patientNum + ", payments=" + payments + ", weight=" + weight + ", height="
				+ height + "]";
	}
	
		
}
