package Logic;

public class Patient_Allergies_List {
	private String PatientNum;
	private String allergiesNum;	
	private String PAist;
	public Patient_Allergies_List(String patientNum, String allergiesNum, String pAist) {
		super();
		PatientNum = patientNum;
		this.allergiesNum = allergiesNum;
		PAist = pAist;
	}
	public String getPatientNum() {
		return PatientNum;
	}
	public void setPatientNum(String patientNum) {
		PatientNum = patientNum;
	}
	public String getAllergiesNum() {
		return allergiesNum;
	}
	public void setAllergiesNum(String allergiesNum) {
		this.allergiesNum = allergiesNum;
	}
	public String getPAist() {
		return PAist;
	}
	public void setPAist(String pAist) {
		PAist = pAist;
	}
	@Override
	public String toString() {
		return "Patient_Allergies_List [PatientNum=" + PatientNum + ", allergiesNum=" + allergiesNum + ", PAist="
				+ PAist + "]";
	}
	
}
