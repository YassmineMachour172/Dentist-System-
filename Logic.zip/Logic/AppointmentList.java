package Logic;

public class AppointmentList {
	
	private int AppointmentNum;
	private int patientNum;
	
	public AppointmentList(int appointmentNum, int patientNum) {
		AppointmentNum = appointmentNum;
		this.patientNum = patientNum;
	}

	public int getAppointmentNum() {
		return AppointmentNum;
	}

	public int getPatientNum() {
		return patientNum;
	}

	public void setAppointmentNum(int appointmentNum) {
		AppointmentNum = appointmentNum;
	}

	public void setPatientNum(int patientNum) {
		this.patientNum = patientNum;
	}

	@Override
	public String toString() {
		return "AppointmentList [AppointmentNum=" + AppointmentNum + ", patientNum=" + patientNum + "]";
	}
	
	
	

}
