package Logic;

public class Allergies {
	private String allergiesNum;
	private String allergiesName;
	private boolean deadly;
	public Allergies(String allergiesNum, String allergiesName, boolean deadly) {
		super();
		this.allergiesNum = allergiesNum;
		this.allergiesName = allergiesName;
		this.deadly = deadly;
	}
	public String getAllergiesNum() {
		return allergiesNum;
	}
	public void setAllergiesNum(String allergiesNum) {
		this.allergiesNum = allergiesNum;
	}
	public String getAllergiesName() {
		return allergiesName;
	}
	public void setAllergiesName(String allergiesName) {
		this.allergiesName = allergiesName;
	}
	public boolean isDeadly() {
		return deadly;
	}
	public void setDeadly(boolean deadly) {
		this.deadly = deadly;
	}
	@Override
	public String toString() {
		return "Allergies [allergiesNum=" + allergiesNum + ", allergiesName=" + allergiesName + ", deadly=" + deadly
				+ "]";
	}
	
}
