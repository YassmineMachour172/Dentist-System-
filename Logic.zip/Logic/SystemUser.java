package Logic;

import java.util.Date;

public abstract class SystemUser extends Person {
	
	private String username;
	private String password;
	private boolean isConnected;
	private String color;
	private String job;
	
	
	public SystemUser(String fName, String lName, String id, Date birthday, String phone, String country, String street,
			String buildingNum, String gender, String username, String password, boolean isConnected, String color,
			String job) {
		super(fName, lName, id, birthday, phone, country, street, buildingNum, gender);
		this.username = username;
		this.password = password;
		this.isConnected = isConnected;
		this.color = color;
		this.job = job;
	}


	public String getUsername() {
		return username;
	}
	public String getPassword() {
		return password;
	}
	public boolean isConnected() {
		return isConnected;
	}
	public String getColor() {
		return color;
	}
	public String getJob() {
		return job;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public void setConnected(boolean isConnected) {
		this.isConnected = isConnected;
	}
	public void setColor(String color) {
		this.color = color;
	}
	public void setJob(String job) {
		this.job = job;
	}
	@Override
	public String toString() {
		return super.toString() + "SystemUser [username=" + username + ", password=" + password + ", isConnected=" + isConnected
				+ ", color=" + color + ", job=" + job + "]";
	}
	
	
	

}
