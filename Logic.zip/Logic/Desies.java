package Logic;

public class Desies {
	private String desiesNum;
	private String desiesName;
	private boolean contages;
	public Desies(String desiesNum, String desiesName, boolean contages) {
		super();
		this.desiesNum = desiesNum;
		this.desiesName = desiesName;
		this.contages = contages;
	}
	public String getDesiesNum() {
		return desiesNum;
	}
	public void setDesiesNum(String desiesNum) {
		this.desiesNum = desiesNum;
	}
	public String getDesiesName() {
		return desiesName;
	}
	public void setDesiesName(String desiesName) {
		this.desiesName = desiesName;
	}
	public boolean isContages() {
		return contages;
	}
	public void setContages(boolean contages) {
		this.contages = contages;
	}
	@Override
	public String toString() {
		return "Desies [desiesNum=" + desiesNum + ", desiesName=" + desiesName + ", contages=" + contages + "]";
	}
	
}
