package Logic;

public class Desies_Symptoms_List {
	private String desiesNum;
	private String symptomNum;
	private String DSList;

	
	public String getDSList() {
		return DSList;
	}
	public void setDSList(String dSList) {
		DSList = dSList;
	}
	public Desies_Symptoms_List(String desiesNum, String symptomNum, String dSList) {
		super();
		this.desiesNum = desiesNum;
		this.symptomNum = symptomNum;
		DSList = dSList;
	}
	public String getDesiesNum() {
		return desiesNum;
	}
	public void setDesiesNum(String desiesNum) {
		this.desiesNum = desiesNum;
	}
	public String getSymptomNum() {
		return symptomNum;
	}
	public void setSymptomNum(String symptomNum) {
		this.symptomNum = symptomNum;
	}
	@Override
	public String toString() {
		return "Desies_Symptoms_List [desiesNum=" + desiesNum + ", symptomNum=" + symptomNum + ", DSList=" + DSList
				+ "]";
	}
	
}
