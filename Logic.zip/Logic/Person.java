package Logic;

import java.util.Date;

public class Person {
	
	private String FName;
	private String LName;
	private String Id;
	private Date Birthday;
	private String phone;
	private String country;
	private String street;
	private String buildingNum;
	private String gender;
	
	
	
	
	public Person(String fName, String lName, String id, Date birthday, String phone, String country, String street,
			String buildingNum, String gender) {
		super();
		FName = fName;
		LName = lName;
		Id = id;
		Birthday = birthday;
		this.phone = phone;
		this.country = country;
		this.street = street;
		this.buildingNum = buildingNum;
		this.gender = gender;
	}
	
	
	public String getFName() {
		return FName;
	}
	public String getLName() {
		return LName;
	}
	public String getId() {
		return Id;
	}
	public Date getBirthday() {
		return Birthday;
	}
	public String getPhone() {
		return phone;
	}
	public String getCountry() {
		return country;
	}
	public String getStreet() {
		return street;
	}
	public String getBuildingNum() {
		return buildingNum;
	}
	public String getGender() {
		return gender;
	}
	public void setFName(String fName) {
		FName = fName;
	}
	public void setLName(String lName) {
		LName = lName;
	}
	public void setId(String id) {
		Id = id;
	}
	public void setBirthday(Date birthday) {
		Birthday = birthday;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	public void setCountry(String country) {
		this.country = country;
	}
	public void setStreet(String street) {
		this.street = street;
	}
	public void setBuildingNum(String buildingNum) {
		this.buildingNum = buildingNum;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	
	@Override
	public String toString() {
		return "Person [FName=" + FName + ", LName=" + LName + ", Id=" + Id + ", Birthday=" + Birthday + ", phone="
				+ phone + ", country=" + country + ", street=" + street + ", buildingNum=" + buildingNum + ", gender="
				+ gender + "]";
	}
	
}
