package Logic;

import java.util.Date;

public abstract class Assistant extends SystemUser {
	
	private int assistNum;
	
	

	public Assistant(String fName, String lName, String id, Date birthday, String phone, String country, String street,
			String buildingNum, String gender, String username, String password, boolean isConnected, String color,
			String job, int assistNum) {
		super(fName, lName, id, birthday, phone, country, street, buildingNum, gender, username, password, isConnected,
				color, job);
		this.assistNum = assistNum;
	}

	public int getAssistNum() {
		return assistNum;
	}

	public void setAssistNum(int assistNum) {
		this.assistNum = assistNum;
	}

	@Override
	public String toString() {
		return super.toString() + "Assistant [assistNum=" + assistNum + "]";
	}
	
	

}
