package Logic;

public class Patient_Drug_List {
	private String PatientNum;
	private String drugNum;	
	private String DList;
	public Patient_Drug_List(String patientNum, String drugNum, String dList) {
		super();
		PatientNum = patientNum;
		this.drugNum = drugNum;
		DList = dList;
	}
	public String getPatientNum() {
		return PatientNum;
	}
	public void setPatientNum(String patientNum) {
		PatientNum = patientNum;
	}
	public String getDrugNum() {
		return drugNum;
	}
	public void setDrugNum(String drugNum) {
		this.drugNum = drugNum;
	}
	public String getDList() {
		return DList;
	}
	public void setDList(String dList) {
		DList = dList;
	}
	@Override
	public String toString() {
		return "Patient_Drug_List [PatientNum=" + PatientNum + ", drugNum=" + drugNum + ", DList=" + DList + "]";
	}
	
}
