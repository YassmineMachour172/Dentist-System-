package Logic;

import java.util.Date;

public class Doctor extends SystemUser {
	
	private int docNum;
	
	

	public Doctor(String fName, String lName, String id, Date birthday, String phone, String country, String street,
			String buildingNum, String gender, String username, String password, boolean isConnected, String color,
			String job, int docNum) {
		super(fName, lName, id, birthday, phone, country, street, buildingNum, gender, username, password, isConnected,
				color, job);
		this.docNum = docNum;
	}

	public int getDocNum() {
		return docNum;
	}

	public void setDocNum(int docNum) {
		this.docNum = docNum;
	}

	@Override
	public String toString() {
		return super.toString() + "Doctor [docNum=" + docNum + "]";
	}
	
	

}
