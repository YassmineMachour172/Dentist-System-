package Logic;

public class TreatmentList {
	
	private int treatmentNum;
	private int AppointmentNum;
	
	
	public TreatmentList(int treatmentNum, int appointmentNum) {
		
		this.treatmentNum = treatmentNum;
		AppointmentNum = appointmentNum;
	}


	public int getTreatmentNum() {
		return treatmentNum;
	}


	public int getAppointmentNum() {
		return AppointmentNum;
	}


	public void setTreatmentNum(int treatmentNum) {
		this.treatmentNum = treatmentNum;
	}


	public void setAppointmentNum(int appointmentNum) {
		AppointmentNum = appointmentNum;
	}


	@Override
	public String toString() {
		return "TreatmentList [treatmentNum=" + treatmentNum + ", AppointmentNum=" + AppointmentNum + "]";
	}
	
	
	

}
