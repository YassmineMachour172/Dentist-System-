package Logic;

public class Patien_Desies_List {
	private String PatientNum;
	private String desiesNum;	
	private String PDEList;
	public Patien_Desies_List(String patientNum, String desiesNum, String pDEList) {
		super();
		PatientNum = patientNum;
		this.desiesNum = desiesNum;
		PDEList = pDEList;
	}
	public String getPatientNum() {
		return PatientNum;
	}
	public void setPatientNum(String patientNum) {
		PatientNum = patientNum;
	}
	public String getDesiesNum() {
		return desiesNum;
	}
	public void setDesiesNum(String desiesNum) {
		this.desiesNum = desiesNum;
	}
	public String getPDEList() {
		return PDEList;
	}
	public void setPDEList(String pDEList) {
		PDEList = pDEList;
	}
	@Override
	public String toString() {
		return "Patien_Desies_List [PatientNum=" + PatientNum + ", desiesNum=" + desiesNum + ", PDEList=" + PDEList
				+ "]";
	}
	
}
