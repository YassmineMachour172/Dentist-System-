package Logic;

public class Symptoms {
	private String symptomNum;
	private String discribtion;
	public Symptoms(String symptomNum, String discribtion) {
		super();
		this.symptomNum = symptomNum;
		this.discribtion = discribtion;
	}
	public String getSymptomNum() {
		return symptomNum;
	}
	public void setSymptomNum(String symptomNum) {
		this.symptomNum = symptomNum;
	}
	public String getDiscribtion() {
		return discribtion;
	}
	public void setDiscribtion(String discribtion) {
		this.discribtion = discribtion;
	}
	@Override
	public String toString() {
		return "Symptoms [symptomNum=" + symptomNum + ", discribtion=" + discribtion + "]";
	}
	

}
