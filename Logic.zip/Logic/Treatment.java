package Logic;

public class Treatment {
	
	private int treatmentNum;
	private String treatmentName;
	private int price;
	
	public Treatment(int treatmentNum, String treatmentName, int price) {
		this.treatmentNum = treatmentNum;
		this.treatmentName = treatmentName;
		this.price = price;
	}

	public int getTreatmentNum() {
		return treatmentNum;
	}

	public String getTreatmentName() {
		return treatmentName;
	}

	public int getPrice() {
		return price;
	}

	public void setTreatmentNum(int treatmentNum) {
		this.treatmentNum = treatmentNum;
	}

	public void setTreatmentName(String treatmentName) {
		this.treatmentName = treatmentName;
	}

	public void setPrice(int price) {
		this.price = price;
	}

	@Override
	public String toString() {
		return "Treatment [treatmentNum=" + treatmentNum + ", treatmentName=" + treatmentName + ", price=" + price
				+ "]";
	}
	
	
	
	

}
