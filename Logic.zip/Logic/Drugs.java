package Logic;

public class Drugs {
	private String drugNum;	
	private String drugName;
	public Drugs(String drugNum, String drugName) {
		super();
		this.drugNum = drugNum;
		this.drugName = drugName;
	}
	public String getDrugNum() {
		return drugNum;
	}
	public void setDrugNum(String drugNum) {
		this.drugNum = drugNum;
	}
	public String getDrugName() {
		return drugName;
	}
	public void setDrugName(String drugName) {
		this.drugName = drugName;
	}
	@Override
	public String toString() {
		return "Drugs [drugNum=" + drugNum + ", drugName=" + drugName + "]";
	}
	
}
