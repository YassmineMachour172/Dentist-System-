package Logic;

import java.util.Date;

public class Appointment {
	
	private int AppointmentNum;
	private Date date;
	private String time;
	private double length;
	private String note;
	
	public Appointment(int appointmentNum, Date date, String time, double length, String note) {
		AppointmentNum = appointmentNum;
		this.date = date;
		this.time = time;
		this.length = length;
		this.note = note;
	}

	public int getAppointmentNum() {
		return AppointmentNum;
	}

	public Date getDate() {
		return date;
	}

	public String getTime() {
		return time;
	}

	public double getLength() {
		return length;
	}

	public String getNote() {
		return note;
	}

	public void setAppointmentNum(int appointmentNum) {
		AppointmentNum = appointmentNum;
	}

	public void setDate(Date date) {
		this.date = date;
	}

	public void setTime(String time) {
		this.time = time;
	}

	public void setLength(double length) {
		this.length = length;
	}

	public void setNote(String note) {
		this.note = note;
	}

	@Override
	public String toString() {
		return "Appointment [AppointmentNum=" + AppointmentNum + ", date=" + date + ", time=" + time + ", length="
				+ length + ", note=" + note + "]";
	}
	
	
	

}
