package Logic;

public class XRAY {
	private String picNum;
	private String picName;
	private String picSrc;
	public XRAY(String picNum, String picName, String picSrc) {
		super();
		this.picNum = picNum;
		this.picName = picName;
		this.picSrc = picSrc;
	}
	public String getPicNum() {
		return picNum;
	}
	public void setPicNum(String picNum) {
		this.picNum = picNum;
	}
	public String getPicName() {
		return picName;
	}
	public void setPicName(String picName) {
		this.picName = picName;
	}
	public String getPicSrc() {
		return picSrc;
	}
	public void setPicSrc(String picSrc) {
		this.picSrc = picSrc;
	}
	@Override
	public String toString() {
		return "XRAY [picNum=" + picNum + ", picName=" + picName + ", picSrc=" + picSrc + "]";
	}
	
}
